<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Pagi_ui-chkbox-box ui-widg</name>
   <tag></tag>
   <elementGuidId>5939106f-3686-43c4-8f1c-725fdd8b5e02</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Pagi'])[1]/following::div[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ui-chkbox-box ui-widget ui-corner-all ui-state-default</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-klass</name>
      <type>Main</type>
      <value>ui-chkbox-box ui-widget ui-cor</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-ng-class</name>
      <type>Main</type>
      <value>[object Object]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;m-page--fluid m--skin-light m-page--loading m-content--skin-light m-header--fixed  m-aside-left--fixed   m-aside-left--enabled m-aside-left--skin-light m-aside-left--offcanvas&quot;]/app-root[1]/ng-component[1]/div[@class=&quot;m-grid m-grid--hor m-grid--root m-page&quot;]/div[@class=&quot;m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body&quot;]/div[@class=&quot;m-grid__item m-grid__item--fluid m-wrapper&quot;]/ng-component[@class=&quot;ng-tns-c3-1&quot;]/div[@class=&quot;ng-tns-c3-1&quot;]/div[@class=&quot;m-content&quot;]/div[@class=&quot;m-portlet&quot;]/div[@class=&quot;m-portlet__body  m-portlet__body--no-padding&quot;]/div[@class=&quot;m-portlet__body&quot;]/div[@class=&quot;row ng-untouched ng-valid ng-dirty&quot;]/div[@class=&quot;col-sm-5 col-md-4 col-lg-3&quot;]/fieldset[@class=&quot;ng-tns-c3-1&quot;]/div[@class=&quot;form-group m-form__group row align-items-center&quot;]/div[@class=&quot;ui-g ng-tns-c3-1&quot;]/div[@class=&quot;ui-g-12 ng-tns-c3-1&quot;]/p-checkbox[@class=&quot;ng-tns-c3-1 ng-untouched ng-pristine ng-valid&quot;]/div[@class=&quot;ui-chkbox ui-widget&quot;]/div[@class=&quot;ui-chkbox-box ui-widget ui-corner-all ui-state-default&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pagi'])[1]/following::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Info period : Already set by system'])[1]/following::div[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Siang'])[1]/preceding::div[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sore'])[1]/preceding::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//div[2]/p-checkbox/div/div[2]</value>
   </webElementXpaths>
</WebElementEntity>
