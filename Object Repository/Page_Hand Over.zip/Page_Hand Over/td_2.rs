<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_2</name>
   <tag></tag>
   <elementGuidId>6dae7d10-5dc8-43ba-9b89-52b334fe1c4e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[1]/following::td[35]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-tns-c4-2 ui-datepicker-other-month ui-state-disabled</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-reflect-ng-class</name>
      <type>Main</type>
      <value>[object Object]</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                
                                    2
                                    
                                
                            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;m-page--fluid m--skin-light m-page--loading m-content--skin-light m-header--fixed  m-aside-left--fixed   m-aside-left--enabled m-aside-left--skin-light m-aside-left--offcanvas&quot;]/app-root[1]/ng-component[1]/div[@class=&quot;m-grid m-grid--hor m-grid--root m-page&quot;]/div[@class=&quot;m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body&quot;]/div[@class=&quot;m-grid__item m-grid__item--fluid m-wrapper&quot;]/ng-component[@class=&quot;ng-tns-c3-1&quot;]/div[@class=&quot;ng-tns-c3-1&quot;]/div[@class=&quot;m-content&quot;]/div[@class=&quot;m-portlet&quot;]/div[@class=&quot;m-portlet__body  m-portlet__body--no-padding&quot;]/div[@class=&quot;m-portlet__body&quot;]/div[@class=&quot;row ng-untouched ng-pristine ng-valid&quot;]/div[@class=&quot;col-sm-5 col-md-4 col-lg-3&quot;]/p-calendar[@class=&quot;ng-tns-c4-2 ng-tns-c3-1 ng-untouched ng-pristine ng-valid&quot;]/span[@class=&quot;ng-tns-c4-2 ui-calendar&quot;]/div[@class=&quot;ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all ui-datepicker-inline ng-trigger ng-trigger-overlayState&quot;]/table[@class=&quot;ui-datepicker-calendar ng-tns-c4-2&quot;]/tbody[@class=&quot;ng-tns-c4-2&quot;]/tr[@class=&quot;ng-tns-c4-2&quot;]/td[@class=&quot;ng-tns-c4-2 ui-datepicker-other-month ui-state-disabled&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sa'])[1]/following::td[35]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Fr'])[1]/following::td[35]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Time Period !'])[1]/preceding::td[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Info period : Already set by system'])[1]/preceding::td[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <value>//tr[5]/td[7]</value>
   </webElementXpaths>
</WebElementEntity>
